# Phishing Email Detection Model (Scikit-learn)

Classifies an email as **Phishing** or **Safe** using its text and URL features, and reports
accuracy, precision/recall/F1, ROC-AUC and a confusion matrix.

## Project structure
```
phishing_detector/
├── data/emails.csv            # dataset (text,label)  1 = Phishing, 0 = Safe
├── generate_dataset.py        # builds a synthetic dataset (offline demo)
├── features.py                # URL / keyword / structural feature extraction
├── train.py                   # train, compare models, evaluate, save artefacts
├── predict.py                 # classify new emails (CLI)
├── models/phishing_model.joblib
├── outputs/                   # confusion_matrix.png, metrics.json, classification_report.txt, top_features.png
└── requirements.txt
```

## Quick start
```bash
pip install -r requirements.txt
python generate_dataset.py          # optional: regenerate data
python train.py                     # trains + prints accuracy & confusion matrix
python predict.py --text "Your account is suspended. Verify at http://bit.ly/x1"
```

## How it works
1. **Data** – CSV with `text` and `label`. Duplicates and empty rows are dropped; 80/20 stratified split.
2. **Feature extraction** (two feature sets combined with `ColumnTransformer`):
   - **TF-IDF** on unigrams + bigrams of the email text.
   - **Hand-crafted features** (`features.py`, 21 values):
     - *URL*: count, unique domains, IP-address URLs, `@` in URL, shorteners (bit.ly…), suspicious TLDs
       (.xyz, .top, .tk…), HTTPS ratio, URL length, dots/hyphens/sub-domains in the domain.
     - *Keywords*: urgency ("suspended", "verify", "within 24 hours"), credentials ("password", "SSN"),
       money/prize words.
     - *Structure*: `!` count, uppercase ratio, length, HTML/form tags, digit ratio.
3. **Models compared** with 5-fold CV: Logistic Regression, Linear SVM (calibrated), Random Forest.
   The best one is refit on the training set and evaluated on the untouched test set.
4. **Outputs**: accuracy, precision, recall, F1, ROC-AUC, confusion matrix (console + PNG), saved model.

## Results (included synthetic dataset, 3,225 unique emails, 645 test emails)
| Metric | Value |
|---|---|
| Accuracy | **98.76 %** |
| Precision (Phishing) | 98.71 % |
| Recall (Phishing) | 99.22 % |
| F1 | 98.97 % |
| ROC-AUC | 0.984 |

Confusion matrix (rows = actual, cols = predicted):

|  | Pred Safe | Pred Phishing |
|---|---|---|
| **Actual Safe** | 253 | 5 |
| **Actual Phishing** | 3 | 384 |

## Using a real dataset (recommended for the final submission)
The bundled data is **synthetic** (template-generated), so its high accuracy mostly shows the pipeline works.
For realistic numbers, download a public corpus, e.g.:
- Kaggle – "Phishing Email Dataset" / "Phishing Email Detection"
- Nazario phishing corpus + Enron / SpamAssassin (legitimate)

Then run:
```bash
python train.py --data path/to/file.csv --text-col "Email Text" --label-col "Email Type"
```
If labels are strings, map them to 1/0 first (e.g. `df["label"] = (df["Email Type"] == "Phishing Email").astype(int)`).
Expect ~95–98 % on real data with this pipeline.

## Limitations / ideas
- Rule-based URL features don't query live reputation services (e.g. Google Safe Browsing, WHOIS age).
- Add email header features (SPF/DKIM, sender/reply-to mismatch) and attachments analysis.
- Try gradient boosting or transformer embeddings for further gains.
