"""Classify one or more emails as Phishing or Safe.

    python predict.py --text "Your account is suspended, verify at http://bit.ly/x1"
    python predict.py --file email.txt
    python predict.py            # interactive mode
"""
import argparse
import joblib
import pandas as pd
from features import extract_features, FEATURE_NAMES  # also needed so joblib can unpickle


def classify(model, text):
    prob = float(model.predict_proba(pd.DataFrame({"text": [text]}))[0, 1])
    return ("Phishing" if prob >= 0.5 else "Safe"), prob


def explain(text):
    f = dict(zip(FEATURE_NAMES, extract_features(text)))
    flags = []
    if f["n_urls"]: flags.append(f"{int(f['n_urls'])} URL(s) found")
    if f["has_ip_url"]: flags.append("URL uses a raw IP address")
    if f["has_at_in_url"]: flags.append("URL contains '@'")
    if f["has_shortener"]: flags.append("URL shortener used")
    if f["has_suspicious_tld"]: flags.append("suspicious TLD")
    if f["max_subdomains"] >= 3: flags.append("many sub-domains")
    if f["n_urgent"]: flags.append(f"{int(f['n_urgent'])} urgency keyword(s)")
    if f["n_credential"]: flags.append(f"{int(f['n_credential'])} credential keyword(s)")
    return flags


def show(model, text):
    label, prob = classify(model, text)
    icon = "[!]" if label == "Phishing" else "[OK]"
    print(f"{icon} {label}  (phishing probability: {prob:.1%})")
    flags = explain(text)
    if flags: print("    Signals:", "; ".join(flags))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--text"); ap.add_argument("--file")
    ap.add_argument("--model", default="models/phishing_model.joblib")
    a = ap.parse_args()
    model = joblib.load(a.model)
    if a.text: show(model, a.text)
    elif a.file: show(model, open(a.file, encoding="utf-8", errors="ignore").read())
    else:
        print("Paste an email (single line), or Ctrl+C to quit.")
        while True:
            show(model, input("\n> "))
