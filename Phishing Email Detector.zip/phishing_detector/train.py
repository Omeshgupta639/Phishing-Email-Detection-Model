"""Train, compare and evaluate phishing-email classifiers.

Usage:
    python train.py                       # uses data/emails.csv
    python train.py --data my_emails.csv --text-col body --label-col is_phishing
"""
import argparse, json, os
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, ConfusionMatrixDisplay,
                             confusion_matrix, precision_recall_fscore_support, roc_auc_score)
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC
from sklearn.calibration import CalibratedClassifierCV

from features import EmailFeatureExtractor, FEATURE_NAMES

LABELS = ["Safe", "Phishing"]


def build_pipeline(clf):
    """TF-IDF text features + hand-crafted URL/keyword features -> classifier."""
    feats = ColumnTransformer([
        ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english", ngram_range=(1, 2),
                                  min_df=2, max_features=20000, sublinear_tf=True), "text"),
        ("handcrafted", Pipeline([("extract", EmailFeatureExtractor()),
                                  ("scale", StandardScaler())]), "text"),
    ])
    return Pipeline([("features", feats), ("clf", clf)])


def main(a):
    os.makedirs("models", exist_ok=True); os.makedirs("outputs", exist_ok=True)
    df = pd.read_csv(a.data).rename(columns={a.text_col: "text", a.label_col: "label"})
    df = df.dropna(subset=["text", "label"]).drop_duplicates(subset="text")
    df["label"] = df["label"].astype(int)
    print(f"Loaded {len(df)} emails | Phishing: {df.label.sum()} | Safe: {(df.label == 0).sum()}")

    X_train, X_test, y_train, y_test = train_test_split(
        df[["text"]], df["label"], test_size=0.2, stratify=df["label"], random_state=42)

    candidates = {
        "LogisticRegression": LogisticRegression(max_iter=2000, C=2.0),
        "LinearSVM": CalibratedClassifierCV(LinearSVC(C=1.0, max_iter=10000), cv=3),
        "RandomForest": RandomForestClassifier(n_estimators=300, random_state=42, n_jobs=-1),
    }

    # --- compare models with 5-fold CV on the training set ---
    cv = StratifiedKFold(5, shuffle=True, random_state=42)
    cv_scores = {}
    for name, clf in candidates.items():
        s = cross_val_score(build_pipeline(clf), X_train, y_train, cv=cv, scoring="accuracy", n_jobs=-1)
        cv_scores[name] = float(s.mean())
        print(f"  CV accuracy  {name:<20s} {s.mean():.4f} (+/- {s.std():.4f})")
    best = max(cv_scores, key=cv_scores.get)
    print(f"Best model by CV: {best}")

    # --- fit best on full training set, evaluate on held-out test set ---
    model = build_pipeline(candidates[best]).fit(X_train, y_train)
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    p, r, f1, _ = precision_recall_fscore_support(y_test, y_pred, average="binary")
    auc = roc_auc_score(y_test, y_prob)
    cm = confusion_matrix(y_test, y_pred)
    report = classification_report(y_test, y_pred, target_names=LABELS)

    print("\n=== TEST SET RESULTS ===")
    print(f"Accuracy : {acc:.4f}\nPrecision: {p:.4f}\nRecall   : {r:.4f}\nF1-score : {f1:.4f}\nROC-AUC  : {auc:.4f}")
    print("\nConfusion matrix (rows=actual, cols=predicted) [Safe, Phishing]:\n", cm)
    print("\n" + report)

    # --- save artefacts ---
    joblib.dump(model, "models/phishing_model.joblib")
    json.dump({"best_model": best, "cv_accuracy": cv_scores, "test_accuracy": acc, "precision": p,
               "recall": r, "f1": f1, "roc_auc": auc, "confusion_matrix": cm.tolist(),
               "n_train": len(X_train), "n_test": len(X_test)},
              open("outputs/metrics.json", "w"), indent=2)
    open("outputs/classification_report.txt", "w").write(f"Model: {best}\nAccuracy: {acc:.4f}\n\n{report}")

    fig, ax = plt.subplots(figsize=(5.2, 4.6))
    ConfusionMatrixDisplay(cm, display_labels=LABELS).plot(ax=ax, cmap="Blues", colorbar=False, values_format="d")
    ax.set_title(f"Confusion Matrix - {best}\nAccuracy = {acc * 100:.2f}%")
    plt.tight_layout(); plt.savefig("outputs/confusion_matrix.png", dpi=150); plt.close()

    # --- most informative hand-crafted/URL features (logistic regression only) ---
    if best == "LogisticRegression":
        names = list(model.named_steps["features"].get_feature_names_out())
        coefs = model.named_steps["clf"].coef_[0]
        top = np.argsort(np.abs(coefs))[-15:]
        plt.figure(figsize=(7, 5))
        plt.barh([names[i].split("__")[-1] for i in top], coefs[top],
                 color=["#d9534f" if c > 0 else "#5cb85c" for c in coefs[top]])
        plt.title("Top features (red -> Phishing, green -> Safe)")
        plt.tight_layout(); plt.savefig("outputs/top_features.png", dpi=150); plt.close()
    print("\nSaved: models/phishing_model.joblib, outputs/confusion_matrix.png, metrics.json, classification_report.txt")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data/emails.csv")
    ap.add_argument("--text-col", default="text")
    ap.add_argument("--label-col", default="label")
    main(ap.parse_args())
