"""Generate a synthetic labelled email dataset (data/emails.csv).

Use this when you don't have a real dataset. For real-world results, replace
data/emails.csv with a public corpus (e.g. Kaggle "Phishing Email Dataset",
Nazario phishing corpus + Enron/SpamAssassin ham) having columns: text,label
(label: 1 = Phishing, 0 = Safe).

The generator deliberately injects overlap/noise (legit emails with urgency
words and links, phishing emails that look polite) so the task is not trivial.
"""
import random
import argparse
import pandas as pd

random.seed(42)

BRANDS = ["PayPal", "Amazon", "Netflix", "Apple", "Microsoft", "HDFC Bank", "SBI", "Google", "Facebook", "DHL"]
NAMES = ["Alex", "Priya", "Rahul", "Sam", "Neha", "John", "Maria", "Amit", "Sara", "David"]
COMPANIES = ["Acme Corp", "Globex", "Initech", "Umbrella Ltd", "Hooli", "Stark Industries"]

def rnd_str(n=8):
    return "".join(random.choices("abcdefghijklmnopqrstuvwxyz0123456789", k=n))

def phish_url(brand):
    b = brand.lower().replace(" ", "")
    kind = random.choice(["ip", "typo", "subdomain", "short", "tld", "at", "plain_https"])
    if kind == "ip":
        return f"http://{random.randint(11,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}/{b}/login.php?id={rnd_str()}"
    if kind == "typo":
        return f"http://{b.replace('a','4',1)}-secure-{rnd_str(4)}.com/verify?session={rnd_str(12)}"
    if kind == "subdomain":
        return f"http://{b}.account.security.{rnd_str(6)}.com/signin"
    if kind == "short":
        return f"http://{random.choice(['bit.ly','tinyurl.com','cutt.ly'])}/{rnd_str(6)}"
    if kind == "tld":
        return f"http://{b}-support.{random.choice(['xyz','top','click','tk'])}/update"
    if kind == "at":
        return f"http://{b}.com@{rnd_str(7)}.ru/login"
    return f"https://{b}-verify-{rnd_str(3)}.net/auth"

def legit_url(brand=None):
    dom = random.choice(["github.com", "linkedin.com", "google.com/calendar", "company.com/intranet",
                         "docs.google.com/document", "zoom.us/j/" + str(random.randint(10**8, 10**9)),
                         "medium.com/@writer", "amazon.com/orders", "netflix.com/browse"])
    return f"https://{dom}"

PHISH_TEMPLATES = [
    "Dear Customer, we detected unusual activity on your {brand} account. Your account will be suspended within 24 hours unless you verify your password immediately: {url}",
    "URGENT: Action required! Your {brand} account has been locked. Confirm your login credentials now at {url} to avoid permanent deactivation.",
    "Congratulations! You are the winner of a $1,000 {brand} gift card. Claim your free prize before it expires: {url}",
    "Security alert from {brand}. Someone tried to sign in from a new device. If this wasn't you, update your billing information here {url}",
    "Final notice: your payment of $%d could not be processed. Please update your credit card details at {url} to keep your {brand} service active.",
    "Hello, a refund of $%d is waiting for you from {brand}. Provide your bank account number and PIN at {url} to receive the cash.",
    "Your mailbox storage is full and emails will be deleted. Sign in to {url} to increase quota. Failure to act will result in loss of data.",
    "Dear user, kindly find the attached invoice. To view it, log in with your email password at {url}.",
    "{brand} Support: we noticed a problem with your account. Click {url} and confirm your SSN and date of birth to restore access.",
    "Hi {name}, I'm stuck abroad and need urgent help. Please send a gift card or wire money, I will refund you. Details: {url}",
]
# polite / subtle phishing (harder cases)
SUBTLE_PHISH = [
    "Hi {name}, the shared document you requested is ready. Please sign in here to view it: {url}",
    "Your {brand} order could not be delivered. Please confirm your address at {url} to reschedule.",
    "Hello, your subscription renewal is pending. Review your invoice at {url}. Thank you, {brand} Billing.",
]

LEGIT_TEMPLATES = [
    "Hi {name}, just a reminder about our team meeting tomorrow at 10 AM. The agenda is in the shared doc: {url}. Thanks, {name2}",
    "Hello {name}, please find the quarterly report attached. Let me know if you have any questions before Friday's review.",
    "Your {brand} order #%d has shipped and will arrive in 3-5 business days. Track it from your account at {url}.",
    "Dear {name}, thank you for registering for our webinar on data engineering. The session starts at 4 PM IST. Join link: {url}",
    "Hey {name}, are we still on for lunch on Saturday? Let me know what time works. Cheers, {name2}",
    "Welcome to {company}! Your onboarding schedule for next week is attached. HR will contact you on Monday.",
    "Hi team, the sprint retrospective notes are in {url}. Please add your comments by end of day. Regards, {name2}",
    "Receipt from {brand}: thank you for your purchase of $%d. No further action is needed. Questions? Reply to this email.",
    "Hi {name}, here's the pull request for the login page refactor: {url}. Could you review it when you get a chance?",
    "Newsletter: Top 5 Python tips this week. Read the full article at {url}. You can unsubscribe at any time.",
]
# legit emails that look "scary" (hard negatives)
TRICKY_LEGIT = [
    "Security notice from {brand}: you changed your password today. If this was you, no action is needed. Visit {url} for account settings.",
    "Reminder: your {brand} subscription will expire next month. You can renew anytime from {url}. Thanks for being a customer!",
    "URGENT: server maintenance tonight at 11 PM. Please save your work and log out. Details on the intranet {url}.",
]

def fill(t):
    if "%d" in t:
        t = t % random.randint(10, 999)
    return t

def make_email(label):
    brand, name, name2, company = (random.choice(BRANDS), random.choice(NAMES),
                                   random.choice(NAMES), random.choice(COMPANIES))
    if label == 1:
        pool = SUBTLE_PHISH if random.random() < 0.25 else PHISH_TEMPLATES
        t = fill(random.choice(pool))
        url = phish_url(brand)
    else:
        pool = TRICKY_LEGIT if random.random() < 0.15 else LEGIT_TEMPLATES
        t = fill(random.choice(pool))
        url = legit_url(brand)
    # sometimes legit mail has no URL, sometimes phishing has none (noise)
    text = t.format(brand=brand, name=name, name2=name2, company=company, url=url)
    if label == 1 and random.random() < 0.08:
        text = text.replace(url, "the link below")
    if random.random() < 0.3:
        text = random.choice(["Subject: Important\n", "Subject: Hello\n", "Subject: Re: update\n", ""]) + text
    if random.random() < 0.1:
        text = text.upper() if label == 1 else text + " Sent from my iPhone."
    # label noise to mimic real-world mislabels
    return text

def main(n, out):
    rows = []
    for i in range(n):
        label = int(i % 2 == 0)
        rows.append((make_email(label), label))
    df = pd.DataFrame(rows, columns=["text", "label"]).sample(frac=1, random_state=1).reset_index(drop=True)
    # ~1% label noise
    flip = df.sample(frac=0.01, random_state=3).index
    df.loc[flip, "label"] = 1 - df.loc[flip, "label"]
    df.to_csv(out, index=False)
    print(f"Saved {len(df)} emails to {out}  (phishing={int(df.label.sum())}, safe={int((1-df.label).sum())})")

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=4000)
    ap.add_argument("--out", default="data/emails.csv")
    a = ap.parse_args()
    main(a.n, a.out)
