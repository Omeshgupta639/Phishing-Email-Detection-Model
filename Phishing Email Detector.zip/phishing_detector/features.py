"""Hand-crafted feature extraction for phishing email detection.

Extracts URL-based, keyword-based and structural features from raw email text.
The transformer is scikit-learn compatible so it plugs into a Pipeline.
"""
import re
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin

URL_RE = re.compile(r"(?:https?://|www\.)[^\s<>\"')]+", re.IGNORECASE)
IP_RE = re.compile(r"^(?:https?://)?\d{1,3}(?:\.\d{1,3}){3}")
SHORTENERS = ("bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "is.gd", "cutt.ly", "rb.gy")
SUSPICIOUS_TLDS = (".xyz", ".top", ".click", ".tk", ".ml", ".ga", ".cf", ".gq", ".work", ".link", ".info", ".ru")

URGENT_WORDS = ["urgent", "immediately", "suspended", "verify", "confirm", "expire", "expires",
                "limited time", "act now", "final notice", "within 24 hours", "locked", "unusual activity",
                "security alert", "action required", "deactivated", "restricted"]
CREDENTIAL_WORDS = ["password", "login", "log in", "sign in", "username", "account number",
                    "ssn", "social security", "pin", "credit card", "bank", "billing", "credentials"]
MONEY_WORDS = ["winner", "prize", "lottery", "free", "gift card", "refund", "claim", "reward",
               "$", "inheritance", "bonus", "cash"]

FEATURE_NAMES = [
    "n_urls", "n_unique_domains", "has_ip_url", "has_at_in_url", "has_shortener", "has_suspicious_tld",
    "frac_https", "max_url_len", "max_url_dots", "max_url_hyphens", "max_subdomains",
    "n_urgent", "n_credential", "n_money",
    "n_exclaim", "frac_upper", "n_chars", "n_words", "has_html", "has_form", "n_digits_frac",
]


def _domain(url: str) -> str:
    u = re.sub(r"^https?://", "", url, flags=re.IGNORECASE)
    return re.split(r"[/?#:]", u)[0].lower()


def extract_features(text: str) -> list:
    text = text or ""
    low = text.lower()
    urls = URL_RE.findall(text)
    domains = [_domain(u) for u in urls]

    n_urls = len(urls)
    has_ip = int(any(IP_RE.match(u) for u in urls))
    has_at = int(any("@" in u for u in urls))
    has_short = int(any(any(s in d for s in SHORTENERS) for d in domains))
    has_tld = int(any(d.endswith(SUSPICIOUS_TLDS) for d in domains))
    frac_https = (sum(u.lower().startswith("https") for u in urls) / n_urls) if n_urls else 0.0
    max_len = max((len(u) for u in urls), default=0)
    max_dots = max((d.count(".") for d in domains), default=0)
    max_hyph = max((d.count("-") for d in domains), default=0)
    max_sub = max((max(d.count(".") - 1, 0) for d in domains), default=0)

    n_urgent = sum(low.count(w) for w in URGENT_WORDS)
    n_cred = sum(low.count(w) for w in CREDENTIAL_WORDS)
    n_money = sum(low.count(w) for w in MONEY_WORDS)

    letters = [c for c in text if c.isalpha()]
    frac_upper = (sum(c.isupper() for c in letters) / len(letters)) if letters else 0.0
    n_chars = len(text)
    n_words = len(text.split())
    digits_frac = (sum(c.isdigit() for c in text) / n_chars) if n_chars else 0.0

    return [
        n_urls, len(set(domains)), has_ip, has_at, has_short, has_tld,
        frac_https, max_len, max_dots, max_hyph, max_sub,
        n_urgent, n_cred, n_money,
        text.count("!"), frac_upper, n_chars, n_words,
        int("<html" in low or "<a href" in low), int("<form" in low), digits_frac,
    ]


class EmailFeatureExtractor(BaseEstimator, TransformerMixin):
    """Turns an iterable of raw email strings into a dense numeric matrix."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([extract_features(t) for t in X], dtype=float)

    def get_feature_names_out(self, input_features=None):
        return np.array(FEATURE_NAMES)
